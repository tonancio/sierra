const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'clave-super-secreta',
  resave: false,
  saveUninitialized: true
}));

// Simulación de usuario
const fakeUser = {
  email: 'prueba@correo.com',
  password: '1234',
  name: 'Juan Pérez'
};

// Rutas de navegación
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'views/index.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'views/login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'views/register.html')));
app.get('/account', (req, res) => {
  if (req.session.user) {
    res.send(`<h1>Bienvenido ${req.session.user.name}</h1><a href="/logout">Cerrar sesión</a>`);
  } else {
    res.redirect('/login');
  }
});
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// Login POST
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (email === fakeUser.email && password === fakeUser.password) {
    req.session.user = fakeUser;
    res.redirect('/account');
  } else {
    res.send('Correo o contraseña incorrectos. <a href="/login">Intentar de nuevo</a>');
  }
});

// Registro POST (solo redirecciona por ahora)
app.post('/register', (req, res) => {
  res.redirect('/account'); // Simulamos que se registró correctamente
});

app.listen(3000, () => console.log('Servidor en http://localhost:3000'));

app.get('/user', (req, res) => {
  if (req.session.user) {
    res.redirect('/account');
  } else {
    res.redirect('/login');
  }
});

app.get('/admin', (req, res) => {
  if (req.session.user && req.session.user.tipo === 'admin') {
    res.sendFile(path.join(__dirname, 'views/admin.html'));
  } else {
    res.status(403).send('Acceso no autorizado');
  }
});

